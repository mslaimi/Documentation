package m2i.formation.app;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

import modulesTests.model.Etudiant;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Etudiant e = new Etudiant("Dupont", "Eric", "1");
		System.out.println(e);
		String str = "abc";
		try {
			Reader fileread = new FileReader("C:\\Users\\Administrateur\\eclipse-workspace\\EtudiantProject\\src\\main\\java\\liste.txt");
			Writer cible = new FileWriter("cible.txt");
			fileread.transferTo(cible);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

}
