module EtudiantProject {
	requires PersonneProject;
}