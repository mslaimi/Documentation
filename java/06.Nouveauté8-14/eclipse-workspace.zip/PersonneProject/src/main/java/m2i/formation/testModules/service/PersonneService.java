package m2i.formation.testModules.service;

import m2i.formation.testModules.model.Personne;

public class PersonneService {

	public static Boolean addPersonne(String n, String p)
	{
		Personne per =new Personne(n,p);
		 return ! per.equals(null);
	}
}
