module PersonneProject {
	exports m2i.formation.testModules.model;
}