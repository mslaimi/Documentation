package m2i.formation.javaNews.classes;

import java.util.function.Function;

public class ExampleCompose {
	public Double calculate(Function<Double, Double> operator, Double d) {
		return operator.apply(d);
	}

	public Double sinus(Double d) {
		System.out.print("sin:");
		return Math.sin(d);

	}

	public Double logarithme(Double d) {
		System.out.print("log:");
		return Math.log(d);

	}

	public Double exposant(Double d) {
		System.out.print("exp");
		return Math.exp(d);

	}
}
