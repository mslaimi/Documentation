package m2i.formation.javaNews;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import m2i.formation.javaNews.Exceptions.EmployeException;
import m2i.formation.javaNews.classes.CompareSalaire;
import m2i.formation.javaNews.classes.Example;
import m2i.formation.javaNews.classes.ExampleCompose;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) throws EmployeException {
		// testSansLambda();
		// testExample();
		// exampleCompose();

		System.out.println(ZonedDateTime.now()
				.format(DateTimeFormatter.ofPattern(" 'la date ' DD ', ' MMM', ' YYYY '. il est'  hh ':' mm ':' ss ")));
		System.out.println(ZonedDateTime.now()
				.format(DateTimeFormatter.ofPattern(" 'la date ' dd ', ' MMMM', ' yyyy '. il est'  H ':' mm ':' ss ")));
		System.out.println(ZonedDateTime.now()
				.format(DateTimeFormatter.ofPattern(" 'la date ' dd ', ' MM', ' yy '.il est ' hh ':' mm ':'  ")));

		List <Employe> personnes = new ArrayList<>();
		personnes.add(new Employe("Bob", 21000));
		personnes.add(new Employe("Pierre", 31000));
		personnes.add(new Employe("Sam", 15000));
		personnes.add(new Employe("Fred", 23000));
		
		String noms = personnes.stream().filter(p -> p.getSalaire() > 20000).sorted((p1, p2) -> p1.getSalaire() > p2.getSalaire() ? 1 : -1).map(p -> p.getSalaire() + " : " + p.getNom()).collect(Collectors.joining(", "));
		System.out.println(noms);
	}

	static void exampleCompose() {
		ExampleCompose ex = new ExampleCompose();
		Function<Double, Double> sin = d -> ex.sinus(d);
		Function<Double, Double> log = d -> ex.logarithme(d);
		Function<Double, Double> exp = d -> ex.exposant(d);
		ExampleCompose compose = new ExampleCompose();
		System.out.println(compose.calculate(sin.compose(log), 0.8));
		System.out.println(compose.calculate(sin.andThen(log), 0.8));
		System.out.println(compose.calculate(sin.compose(log).andThen(exp), 0.8));
		System.out.println(compose.calculate(sin.compose(log).compose(exp), 0.8));
		System.out.println(compose.calculate(sin.andThen(log).compose(exp), 0.8));
		System.out.println(compose.calculate(sin.andThen(log).andThen(exp), 0.8));
	}

	static void testExample() {
		Example ex = new Example();
		ex.oper((a, b) -> Example.mul(a, b), 4, 2);
		ex.oper(Example::mul, 3, 5);
		ex.operC(() -> {
			return new GregorianCalendar();
		});
		ex.operC(GregorianCalendar::new);

	}

	public static void testLambda() throws EmployeException {
		Entreprise e1 = new Entreprise("IBM");
		e1.ajouter(new Employe("Dupond", 5000));
		e1.ajouter(new Employe("Poiret", 6000));
		e1.ajouter(new Employe("Burot", 5700));
		e1.ajouter(new Employe("Pernaut", 4300));
		System.out.println(e1);

		// Remplit une liste avec les employés
		List<Employe> l = new ArrayList<>();
		for (Employe e : e1) {
			l.add(e);
		}

		// Tri par salaires croissants
		Comparator<Employe> comparateur = (elt1, elt2) -> {
			return Double.compare(elt1.getSalaire(), elt2.getSalaire());
		};

		Collections.sort(l, comparateur);
//		System.out.println("avec collection.sort");
//		Collections.sort(l,(elt1,elt2)-> Double.compare(elt1.getSalaire(), elt2.getSalaire()));
//		l.forEach(e -> System.out.println(e.getNom() + " gagne " + e.getSalaire()));
//		System.out.println("avec liste.sort");
//		l.sort((elt1,elt2)-> Double.compare(elt1.getSalaire(), elt2.getSalaire()));
//		l.forEach(e -> System.out.println(e.getNom() + " gagne " + e.getSalaire()));
		System.out.println("Employés de " + e1.getNom() + " par ordre croissant des salaires");

		l.forEach(e -> System.out.println(e.getNom() + " gagne " + e.getSalaire()));
	}

	public static void testSansLambda() throws EmployeException {
		Entreprise e1 = new Entreprise("IBM");
		e1.ajouter(new Employe("Dupond", 5000));
		e1.ajouter(new Employe("Poiret", 6000));
		e1.ajouter(new Employe("Burot", 5700));
		e1.ajouter(new Employe("Pernaut", 4300));
		System.out.println(e1);

		// Remplit une liste avec les employés
		List<Employe> l = new ArrayList<>();
		for (Employe e : e1) {
			l.add(e);
		}

		// Tri par salaires croissants
		CompareSalaire comparateur = new CompareSalaire();
		Collections.sort(l, comparateur);
		System.out.println("Employés de " + e1.getNom() + " par ordre croissant des salaires");
		for (Employe employe : l) {
			System.out.println(employe.getNom() + " gagne " + employe.getSalaire());
		}

	}

}
