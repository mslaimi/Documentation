package m2i.formation.javaNews;

import java.util.ArrayList;
import java.util.Iterator;

import m2i.formation.javaNews.Exceptions.EmployeException;

public class Entreprise implements Iterable<Employe> {

	private String nom;
	private ArrayList<Employe> employes;

	public Entreprise(String nom) {
		this.nom = nom;
		employes = new ArrayList<Employe>();
	}

	public String getNom() {
		return nom;
	}

	public void ajouter(Employe emp) throws EmployeException {
		if (!employes.add(emp)) {
			throw new EmployeException("Employé déjà dans cette entreprise", emp);
		}
	}

	public Iterator<Employe> iterator() {
		return employes.iterator();
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer(nom);
		for (Employe employe : employes) {
			sb.append("\n   " + employe.getNom());
		}
		return sb.toString();
	}


}
