package m2i.formation.javaNews.interfaces;

@FunctionalInterface
public interface Vehicule {

	void rouler();
	default void arreter()
	{
		System.out.println("la véhicule s'arrete");
	}
}
