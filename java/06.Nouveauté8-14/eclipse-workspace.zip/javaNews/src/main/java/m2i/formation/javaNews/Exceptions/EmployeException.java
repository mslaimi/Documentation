package m2i.formation.javaNews.Exceptions;

import m2i.formation.javaNews.Employe;

public class EmployeException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmployeException(String message) {
		super(message);
	}

	public EmployeException(String msg, Employe emp) {
		super(msg);
	}
}