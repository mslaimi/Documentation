package m2i.formation.Exercices.model;

public class Produit {
	private String name;
	private double price;
	private double tva;

	public Produit(String name, double price, double tva) {
		this.name = name;
		this.price = price;
		this.setTva(tva);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getTva() {
		return tva;
	}

	public void setTva(double tva) {
		if (tva == 20 || tva == 5.5)
			this.tva = tva;
		else
			tva = 0;
	}

	@Override
	public String toString() {
		return "Produit [name=" + name + ", price=" + price + ", tva=" + tva + "]";
	}

}
