package m2i.formation.Exercices;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import m2i.formation.Exercices.model.Point;
import m2i.formation.Exercices.model.Produit;
import m2i.formation.Exercices.services.ProduitService;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		testStreamPoint();
		/*
		 * 
		 */
	}

	public static void testProduit() {
		ProduitService service = new ProduitService();
		service.readFile("C:\\Users\\Administrateur\\eclipse-workspace\\Exercices\\src\\main\\java\\product.csv");
		List<Produit> listeProduit = new ArrayList<>();
		listeProduit = service
				.streamFile("C:\\Users\\Administrateur\\eclipse-workspace\\Exercices\\src\\main\\java\\product.csv");
		listeProduit.stream().forEach(System.out::println);
		//prix moyen TTC
		double moyenne = listeProduit.stream().mapToDouble(p -> p.getPrice() * (1 + p.getTva() / 100)).average()
				.orElse(0);
		// sinon ajouter .getAsDouble() à la place de orElse(0);
		System.out.println("prix moyen TTC: " + moyenne);
		
		// filtrer les produits avec tva 5.5 et prix < 100
		listeProduit.stream().filter(p -> p.getTva() == 5.5).filter(p -> p.getPrice() < 100)
				.forEach(System.out::println);
	}

	public static void testStream() {
		int[] tab = { 3, 5, -3, 8, 12, 4, 7, 4, 8, 3 };
		long nb = IntStream.of(tab).filter(xx -> xx > 0).count(); // 1
		System.out.println("nb = " + nb);
		IntStream.of(tab).filter(xx -> xx > 3).sorted().forEach(xx -> System.out.print(xx + " "));
		System.out.println();
		IntStream.of(tab).filter(xx -> xx > 3).sorted().distinct().forEach(xx -> System.out.print(xx + " "));
		int s = IntStream.of(tab).map(xx -> Math.abs(xx)).map(xx -> xx * xx).sum();
		System.out.println("\nresultat = " + s);
	}

	public static void traiteListe(ArrayList<Point> liste, Predicate<Point> selec, Comparator<Point> comp,
			Consumer<Point> aff) {
		liste.stream().filter(selec).sorted(comp).forEach(aff);
	}

	public static void testStreamPoint() {
		Point p1 = new Point(2, 5), p2 = new Point(-2, 3), p3 = new Point(6, -3), p4 = new Point(-3, -2);
		ArrayList<Point> l = new ArrayList<Point>();
		l.add(p1);
		l.add(p2);
		l.add(p3);
		l.add(p4);
		// sélection des points d'abscisse positive, tri sur l'abscisse
		l.stream().filter(ee -> ee.getX() > 0).sorted(Comparator.comparing(xx -> xx.getX())).forEach(Point::affiche);
		System.out.println();
		// tri de tous les points suivant la somme des coordonnees
		l.stream().sorted(Comparator.comparing(xx -> xx.getX() + xx.getY()))
				.forEach(xx -> System.out.print("(abs=" + xx.getX() + ", ord=" + xx.getY() + ")  "));
	}
}
