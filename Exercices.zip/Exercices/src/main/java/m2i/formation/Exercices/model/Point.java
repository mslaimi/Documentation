package m2i.formation.Exercices.model;

public class Point {
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public void affiche() {
		System.out.print(" [ " + x + ", " + y + "] ");
	}

	private int x, y;
}
