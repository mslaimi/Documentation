package m2i.formation.Exercices.services;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import m2i.formation.Exercices.model.Produit;

public class ProduitService {
	public List<Produit> readFile(String filePath) {
		// lecture du fichier avec BufferedReader
		BufferedReader br = null;
		String ligne = null;
		List<Produit> listeProduit = new ArrayList<>();
		try {
			br = new BufferedReader(new FileReader(filePath));
			while ((ligne = br.readLine()) != null) {
				String[] rec = ligne.split(";");
				Produit prod = new Produit(rec[0], Double.parseDouble(rec[1]), Double.parseDouble(rec[2]));
				listeProduit.add(prod);
			}
			br.close();
			return listeProduit;
		} catch (IOException e) {

		}
		return listeProduit;
	}

	public List<Produit> streamFile(String filePath) {
		List<Produit> listeProduit = new ArrayList<>();
		try {
			Stream<String> pStream = Files.lines(Paths.get(filePath));
			pStream.forEach(l -> {
				String[] rec = l.split(";");
				Produit prod = new Produit(rec[0], Double.parseDouble(rec[1]), Double.parseDouble(rec[2]));
				listeProduit.add(prod);
			});
		} catch (Exception e) {

		}
		return listeProduit;

	}
	public double prixMoyenTTC(List<Produit> listeProduit)
	{
		return listeProduit.stream().mapToDouble(p->p.getPrice()*p.getTva()).sum() / listeProduit.size();
	}

}
